package pl.example.spring.punkty;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PunktyApplication {
    public static void main(String[] args) {
        SpringApplication.run(PunktyApplication.class, args);
    }

}
